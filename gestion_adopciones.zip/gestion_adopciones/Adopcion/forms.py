# Adopcion/forms.py

from django import forms
from .models import Animal

class AnimalForm(forms.ModelForm):
    class Meta:
        model = Animal
        fields = ['nombre', 'especie', 'raza', 'edad', 'sexo', 'estado_salud', 'estado_disponibilidad']
from django import forms
from .models import Adoptante

class AdoptanteForm(forms.ModelForm):
    class Meta:
        model = Adoptante
        fields = ['nombre', 'direccion', 'telefono', 'email']
#-----------------------------------------
from django import forms
from .models import Animal

class AnimalForm(forms.ModelForm):
    class Meta:
        model = Animal
        fields = ['nombre', 'especie', 'raza', 'edad', 'sexo', 'estado_salud']

    def clean_edad(self):
        edad = self.cleaned_data.get('edad')
        if edad < 0:
            raise forms.ValidationError("La edad no puede ser negativa.")
        return edad
#------------------------------------------
from django import forms
from .models import Adopcion

class AdopcionForm(forms.ModelForm):
    class Meta:
        model = Adopcion
        fields = ['animal', 'adoptante']  # Excluir 'fecha_adopcion'
