from django.apps import AppConfig


class AdopcionConfig(AppConfig):
    name = 'Adopcion'
