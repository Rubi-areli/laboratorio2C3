from django import forms
from .models import Adoptante

class AdoptanteForm(forms.ModelForm):
    class Meta:
        model = Adoptante
        fields = ['nombre', 'telefono', 'correo', 'direccion']


from django import forms
from .models import Animal

class AnimalForm(forms.ModelForm):
    class Meta:
        model = Animal
        fields = ['nombre', 'especie', 'raza', 'edad', 'sexo', 'estado_salud']


from django import forms
from .models import Adoptante

class AdoptanteForm(forms.ModelForm):
    class Meta:
        model = Adoptante
        fields = ['nombre', 'apellido', 'telefono', 'correo', 'direccion']


from django import forms
from .models import Adopcion

class AdopcionForm(forms.ModelForm):
    class Meta:
        model = Adopcion
        fields = ['animal', 'adoptante', 'fecha_adopcion']  # Ajusta los campos según tu modelo
