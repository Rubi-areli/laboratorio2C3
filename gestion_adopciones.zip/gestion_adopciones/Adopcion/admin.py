#from django.contrib import admin

# Register your models here.
#from django.contrib import admin
#from .models import Animal

#admin.site.register(Animal)

#from django.contrib import admin
#from .models import Adoptante

#admin.site.register(Adoptante)

#from django.contrib import admin
#from .models import Adopcion

#admin.site.register(Adopcion)
