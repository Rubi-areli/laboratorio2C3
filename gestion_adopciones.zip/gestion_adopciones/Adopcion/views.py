
# Create your views here.
# Adopcion/views.py



from django.shortcuts import render
from .models import Animal

def consulta_animales(request):
    animales = Animal.objects.all()  # Obtén todos los animales de la base de datos
    return render(request, 'Adopcion/consulta_animales.html', {'animales': animales})


from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect

@login_required
def consulta_animales(request):
    animales = Animal.objects.all()
    return render(request, 'Adopcion/consulta_animales.html', {'animales': animales})


from django.shortcuts import render, redirect
from .forms import AdoptanteForm

def registrar_adoptante(request):
    if request.method == 'POST':
        form = AdoptanteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('consulta_adoptantes')  # Redirige a la vista de consulta
    else:
        form = AdoptanteForm()
    return render(request, 'Adopcion/registrar_adoptante.html', {'form': form})

from .models import Adoptante

def consulta_adoptantes(request):
    adoptantes = Adoptante.objects.all()
    return render(request, 'Adopcion/consulta_adoptantes.html', {'adoptantes': adoptantes})


from django.shortcuts import render, redirect
from .forms import AnimalForm, AdoptanteForm
from .models import Animal,Adoptante

def registrar_animal(request):
    if request.method == 'POST':
        form = AnimalForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('consulta_animales')  # Cambia a la vista de consulta
    else:
        form = AnimalForm()
    return render(request, 'Adopcion/registrar_animal.html', {'form': form})
#------------------------------------------------
from .forms import AdoptanteForm
from .models import Adoptante

def registrar_adoptante(request):
    if request.method == 'POST':
        form = AdoptanteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('consulta_adoptantes')  # 
    else:
        form = AdoptanteForm()
    return render(request, 'Adopcion/registrar_adoptante.html', {'form': form})
#---------------------------------------------
from django.shortcuts import get_object_or_404, render, redirect
from .models import Animal
from .forms import AnimalForm

def editar_animal(request, id):
    # Buscar el animal que se va a editar
    animal = get_object_or_404(Animal, ID_Animal=id)

    if request.method == 'POST':
        form = AnimalForm(request.POST, instance=animal)
        if form.is_valid():
            form.save()
            return redirect('consulta_animales')  # Cambia esto por la vista adecuada
    else:
        form = AnimalForm(instance=animal)

    return render(request, 'Adopcion/editar_animal.html', {'form': form})

#-------------------------------------------------------

from django.shortcuts import get_object_or_404, redirect
from .models import Animal

def eliminar_animal(request, id):
    # Buscar el animal por su ID correcto
    animal = get_object_or_404(Animal, ID_Animal=id)
    animal.delete()  # Eliminar el registro
    return redirect('consulta_animales')  



#----------------------------------------
from django.shortcuts import render, redirect, get_object_or_404
from .models import Adopcion
from .forms import AdopcionForm

def registrar_adopcion(request):
    if request.method == 'POST':
        form = AdopcionForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('consulta_adopciones')
    else:
        form = AdopcionForm()
    return render(request, 'Adopcion/registrar_adopcion.html', {'form': form})

def consulta_adopciones(request):
    adopciones = Adopcion.objects.all()
    return render(request, 'Adopcion/consulta_adopciones.html', {'adopciones': adopciones})

def editar_adopcion(request, id):
    adopcion = get_object_or_404(Adopcion, id=id)
    if request.method == 'POST':
        form = AdopcionForm(request.POST, instance=adopcion)
        if form.is_valid():
            form.save()
            return redirect('consulta_adopciones')
    else:
        form = AdopcionForm(instance=adopcion)
    return render(request, 'Adopcion/editar_adopcion.html', {'form': form})

def eliminar_adopcion(request, id):
    adopcion = get_object_or_404(Adopcion, id=id)
    adopcion.delete()
    return redirect('consulta_adopciones')

from .forms import AdopcionForm
#-------------------------------------------
from django.shortcuts import render
from .models import Adopcion

def consulta_adopciones(request):
    adopciones = Adopcion.objects.all()
    return render(request, 'Adopcion/consulta_adopciones.html', {'adopciones': adopciones})

from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect

def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # Cambia 'home' por el nombre de tu vista principal
        else:
            return render(request, 'login.html', {'error': 'Usuario o contraseña incorrectos'})
    return render(request, 'login.html')


from django.contrib.auth import logout
from django.shortcuts import redirect

def logout_view(request):
    logout(request)
    return redirect('login')  # Redirige a la página de inicio de sesión

def home_view(request):
    return render(request, 'Adopcion/home.html')

from django.shortcuts import render
from .models import Adopcion  # Ajusta el nombre del modelo si es diferente

def reporte_adopciones(request):
    adopciones = Adopcion.objects.all()  # Obtén todas las adopciones
    return render(request, 'Adopcion/reporte_adopciones.html', {'adopciones': adopciones})


import csv
from django.http import HttpResponse
from .models import Adopcion  # Usa el modelo correcto

def descargar_reporte_adopciones_csv(request):
    # Crear una respuesta HTTP con el encabezado para descargar un archivo CSV
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="reporte_adopciones.csv"'

    # Crear un escritor CSV
    writer = csv.writer(response)
    writer.writerow(['ID', 'Adoptante', 'Animal', 'Fecha de Adopción'])  # Ajusta los campos según tu modelo

    # Agregar los datos al CSV
    for adopcion in Adopcion.objects.all():
        writer.writerow([adopcion.id, adopcion.adoptante.nombre, adopcion.animal.nombre, adopcion.fecha_adopcion])

    return response
