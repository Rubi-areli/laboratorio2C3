# Adopcion/urls.py

from django.urls import path
from . import views
from django.contrib import admin
from django.urls import path, include
from Adopcion import views
from Adopcion.views import login_view
urlpatterns = [
    path('registro/', views.registrar_animal, name='registrar_animal'),  # Asegúrate de que la URL es correcta
    path('consulta/', views.consulta_animales, name='consulta_animales'),
    path('registrar_adoptante/', views.registrar_adoptante, name='registrar_adoptante'),
    path('consulta_adoptantes/', views.consulta_adoptantes, name='consulta_adoptantes'),
    path('eliminar/<int:id>/', views.eliminar_animal, name='eliminar_animal'),
    path('home/', views.consulta_animales, name='home'),
    #path('admin/', admin.site.urls),
   # path('', views.consulta_adopciones, name='home'),
   path('', include('Adopcion.urls')),   # Redirigir al listado de adopciones
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('registrar_adopcion/', views.registrar_adopcion, name='registrar_adopcion'),
    path('consulta_adopciones/', views.consulta_adopciones, name='consulta_adopciones'),
    path('editar_adopcion/<int:id>/', views.editar_adopcion, name='editar_adopcion'),
   path('editar_animal/<int:id>/', views.editar_animal, name='editar_animal'),

    path('eliminar_adopcion/<int:id>/', views.eliminar_adopcion, name='eliminar_adopcion'),
]


