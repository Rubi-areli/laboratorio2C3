from django.contrib.auth.models import AbstractUser
from django.db import models

# Modelo personalizado de usuario
      #  return self.username
      


class CustomerUser(AbstractUser):
    telefono = models.CharField(max_length=15, blank=True)  # Campo adicional

# Modelo para animales
class Animal(models.Model):
    ID_Animal = models.AutoField(primary_key=True)
    nombre = models.CharField(max_length=50)
    especie = models.CharField(max_length=50)
    raza = models.CharField(max_length=50, null=True, blank=True)
    edad = models.PositiveIntegerField()
    sexo = models.CharField(max_length=10)
    estado_salud = models.CharField(max_length=100)
    estado_disponibilidad = models.CharField(max_length=20, default="Disponible")
    fecha_registro = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'Animales'  # Nombre exacto de la tabla en la base de datos

    def __str__(self):
        return self.nombre

# Modelo para adoptantes
class Adoptante(models.Model):
    nombre = models.CharField(max_length=50)
    direccion = models.CharField(max_length=255, default="No especificada")
    telefono = models.CharField(max_length=15)
    email = models.EmailField(unique=True, default="default@email.com")
    fecha_registro = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'Adopcion_adoptante'

    def __str__(self):
        return self.nombre

# Modelo para las adopciones
class Adopcion(models.Model):
    adoptante = models.ForeignKey('Adoptante', on_delete=models.CASCADE)
    animal = models.ForeignKey('Animal', on_delete=models.CASCADE, db_column='ID_Animal')  # Ajustar el nombre de la columna
    fecha_adopcion = models.DateField()

    class Meta:
        db_table = 'Adopcion_adopcion'

    def __str__(self):
        return f"{self.animal.nombre} adoptado por {self.adoptante.nombre}"


