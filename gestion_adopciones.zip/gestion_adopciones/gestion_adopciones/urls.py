"""
URL configuration for gestion_adopciones project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from Adopcion import views
urlpatterns = [
 
    path('admin/', admin.site.urls),
     path('', include('Adopcion.urls')), #Aquí se incluyen las URLs de la app Adopcion 
]
#from django.contrib.auth import views as auth_views


from django.contrib import admin
from django.urls import path, include
from Adopcion import views
urlpatterns = [
  
     # Ruta de admin
   # path('', views.consulta_adopciones, name='home'),
     path('home/', views.home_view, name='home'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('registrar_adopcion/', views.registrar_adopcion, name='registrar_adopcion'),
    path('consulta_adopciones/', views.consulta_adopciones, name='consulta_adopciones'),
    path('editar_adopcion/<int:id>/', views.editar_adopcion, name='editar_adopcion'),
    path('eliminar_adopcion/<int:id>/', views.eliminar_adopcion, name='eliminar_adopcion'),
    path('registro/', views.registrar_animal, name='registrar_animal'),  # Asegúrate de que la URL es correcta
    path('consulta/', views.consulta_animales, name='consulta_animales'),
    path('registrar_adoptante/', views.registrar_adoptante, name='registrar_adoptante'),
    path('consulta_adoptantes/', views.consulta_adoptantes, name='consulta_adoptantes'),
    path('eliminar/<int:id>/', views.eliminar_animal, name='eliminar_animal'),
    path('editar_animal/<int:id>/', views.editar_animal, name='editar_animal'),
  # Ruta para mostrar el reporte
    path('reporte_adopciones/', views.reporte_adopciones, name='reporte_adopciones'),

    # Ruta para descargar el reporte como CSV
    path('reporte_adopciones_csv/', views.descargar_reporte_adopciones_csv, name='descargar_reporte_adopciones_csv'),
]





