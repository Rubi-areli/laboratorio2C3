import pyodbc

try:
    # Conexión a la base de datos
    conn = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=26.60.101.255;"
        "DATABASE=AdopcionAnimalesBD;"
        "UID=Sentelmy;"
        "PWD=654321;"
    )
    print("Conexión exitosa")

    # Crear un cursor para ejecutar consultas
    cursor = conn.cursor()

    # Insertar datos en la tabla Animales
    cursor.execute("""
        INSERT INTO Animales (Nombre, Especie, Raza, Edad, Sexo, Estado_Salud)
        VALUES (?, ?, ?, ?, ?, ?)
    """, ('Max', 'Perro', 'Labrador', 3, 'Macho', 'Saludable'))

    conn.commit()  # Confirmar los cambios
    print("Datos insertados correctamente.")

except Exception as e:
    print(f"Error al insertar datos: {e}")

finally:
    # Cerrar la conexión
    if 'conn' in locals() and conn:
        conn.close()
        print("\nLa conexión ha sido cerrada.")
