import pyodbc
try:
    connection = pyodbc.connect(
        "DRIVER={ODBC Driver 17 for SQL Server};"
        "SERVER=26.60.101.255;"
        "DATABASE=AdopcionAnimalesBD;"
        "UID=Sentelmy;"
        "PWD=654321;"
    )
    print("Conexión exitosa.")
    cursor = connection.cursor()
    cursor.execute("SELECT @@VERSION;")
    version = cursor.fetchone()
    print(f"Versión del servidor SQL: {version[0]}")
except Exception as ex:
    print(f"Error durante la conexión: {ex}")
#finally:
    #if 'connection' in locals() and connection:
       # connection.close()
        #print("La conexión ha finalizado.")
